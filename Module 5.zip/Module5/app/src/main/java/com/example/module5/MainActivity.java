package com.example.module5;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText nameText;
    private Button buttonSayHello;
    private TextView textGreeting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameText = findViewById(R.id.nameText);
        buttonSayHello = findViewById(R.id.buttonSayHello);
        textGreeting = findViewById(R.id.textGreeting);

        buttonSayHello.setEnabled(false);

        nameText.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(
                    CharSequence s, int start, int count, int after) {
                // No action needed before text changes
            }

            @Override
            public void onTextChanged(
                    CharSequence s, int start, int before, int count) {

                // Enable the button only when text is entered
                buttonSayHello.setEnabled(
                        s != null && s.toString().trim().length() > 0
                );
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    public void SayHello(View view) {

        String name = nameText.getText().toString().trim();

        if (nameText.getText() == null || name.isEmpty()) {
            return;
        }

        textGreeting.setText("Hello " + name);
    }
}