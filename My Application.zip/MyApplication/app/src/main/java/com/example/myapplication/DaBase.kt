package com.example.myapplication

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class EventDatabase(context: Context) :
    SQLiteOpenHelper(context, "EventEase.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE users (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "username TEXT NOT NULL, " +
                    "password TEXT NOT NULL)"
        )

        db.execSQL(
            "CREATE TABLE events (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "name TEXT NOT NULL, " +
                    "date TEXT NOT NULL, " +
                    "time TEXT NOT NULL, " +
                    "location TEXT, " +
                    "description TEXT)"
        )
    }

    override fun onUpgrade(
        db: SQLiteDatabase,
        oldVersion: Int,
        newVersion: Int
    ) {
        db.execSQL("DROP TABLE IF EXISTS users")
        db.execSQL("DROP TABLE IF EXISTS events")
        onCreate(db)
    }

    fun addUser(username: String, password: String): Boolean {
        val values = ContentValues()
        values.put("username", username)
        values.put("password", password)
        val result = writableDatabase.insert("users", null, values)
        return result != -1L
    }

    fun checkUser(username: String, password: String): Boolean {
        val cursor = readableDatabase.rawQuery(
            "SELECT * FROM users WHERE username = ? AND password = ?",
            arrayOf(username, password)
        )
        val exists = cursor.count > 0
        cursor.close()
        return exists
    }

    fun addEvent(
        name: String,
        date: String,
        time: String,
        location: String,
        description: String
    ): Boolean {
        val values = ContentValues()
        values.put("name", name)
        values.put("date", date)
        values.put("time", time)
        values.put("location", location)
        values.put("description", description)
        val result = writableDatabase.insert("events", null, values)
        return result != -1L
    }

    fun getEvents(): ArrayList<Event> {
        val events = ArrayList<Event>()
        val cursor = readableDatabase.rawQuery(
            "SELECT * FROM events ORDER BY date, time",
            null
        )
        while (cursor.moveToNext()) {
            val event = Event(
                cursor.getInt(cursor.getColumnIndexOrThrow("id")),
                cursor.getString(cursor.getColumnIndexOrThrow("name")),
                cursor.getString(cursor.getColumnIndexOrThrow("date")),
                cursor.getString(cursor.getColumnIndexOrThrow("time")),
                cursor.getString(cursor.getColumnIndexOrThrow("location")),
                cursor.getString(cursor.getColumnIndexOrThrow("description"))
            )
            events.add(event)
        }
        cursor.close()
        return events
    }

    fun updateEvent(
        id: Int,
        name: String,
        date: String,
        time: String,
        location: String,
        description: String
    ): Boolean {
        val values = ContentValues()
        values.put("name", name)
        values.put("date", date)
        values.put("time", time)
        values.put("location", location)
        values.put("description", description)
        val result = writableDatabase.update(
            "events",
            values,
            "id = ?",
            arrayOf(id.toString())
        )
        return result > 0
    }

    fun deleteEvent(id: Int): Boolean {
        val result = writableDatabase.delete(
            "events",
            "id = ?",
            arrayOf(id.toString())
        )
        return result > 0
    }
}
