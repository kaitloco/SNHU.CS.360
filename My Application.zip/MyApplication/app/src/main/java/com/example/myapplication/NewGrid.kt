package com.example.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class EventAdapter(
    private var events: ArrayList<Event>,
    private val onEdit: (Event) -> Unit,
    private val onDelete: (Event) -> Unit
) : RecyclerView.Adapter<EventAdapter.EventViewHolder>() {

    class EventViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.eventName)
        val date: TextView = view.findViewById(R.id.eventDate)
        val time: TextView = view.findViewById(R.id.eventTime)
        val location: TextView = view.findViewById(R.id.eventLocation)
        val description: TextView = view.findViewById(R.id.eventDescription)
        val editButton: Button = view.findViewById(R.id.editButton)
        val deleteButton: Button = view.findViewById(R.id.deleteButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.event_item, parent, false)
        return EventViewHolder(view)
    }

    override fun onBindViewHolder(holder: EventViewHolder, position: Int) {
        val event = events[position]
        holder.name.text = event.name
        holder.date.text = event.date
        holder.time.text = event.time
        holder.location.text = event.location
        holder.description.text = event.description

        holder.editButton.setOnClickListener {
            onEdit(event)
        }

        holder.deleteButton.setOnClickListener {
            onDelete(event)
        }
    }

    override fun getItemCount(): Int {
        return events.size
    }

    fun updateEvents(newEvents: ArrayList<Event>) {
        events = newEvents
        notifyDataSetChanged()
    }
}
