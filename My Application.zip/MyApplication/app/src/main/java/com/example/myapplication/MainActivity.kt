package com.example.myapplication

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var database: EventDatabase
    private val smsPermissionCode = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.home_screen)

        database = EventDatabase(this)

        val addEventButton = findViewById<Button>(R.id.btnAddEvent)
        val openCalendarButton = findViewById<Button>(R.id.btnOpenCalendar)
        val openNotificationsButton = findViewById<Button>(R.id.btnOpenNotifications)
        val openSettingsButton = findViewById<Button>(R.id.btnOpenSettings)

        addEventButton?.setOnClickListener {
            Toast.makeText(this, "Add Event", Toast.LENGTH_SHORT).show()
        }

        openCalendarButton?.setOnClickListener {
            Toast.makeText(this, "Calendar", Toast.LENGTH_SHORT).show()
        }

        openNotificationsButton?.setOnClickListener {
            requestSmsPermission()
            Toast.makeText(this, "SMS Notifications", Toast.LENGTH_SHORT).show()
        }

        openSettingsButton?.setOnClickListener {
            Toast.makeText(this, "Settings", Toast.LENGTH_SHORT).show()
        }

        requestSmsPermission()
    }

    private fun requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.SEND_SMS),
                smsPermissionCode
            )
        }
    }
}
