package com.example.module6;

import android.Manifest;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.animation.OvershootInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity
        implements SensorEventListener {

    private SensorManager sensorManager;
    private Sensor accelerometer;

    private TextView sensorValues;
    private TextView profileCircle;
    private TextView todayDate;

    private LinearLayout entryForm;
    private LinearLayout entriesContainer;

    private EditText entryTitle;
    private EditText entryBody;

    private Button todayButton;
    private Button saveButton;
    private Button cancelButton;

    private SharedPreferences preferences;

    private static final String PREFS = "TanjaDiary";
    private static final String ENTRIES_KEY = "entries";
    private static final String CHANNEL_ID = "diary_notifications";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sensorValues = findViewById(R.id.sensorValues);
        profileCircle = findViewById(R.id.profileCircle);
        todayDate = findViewById(R.id.todayDate);
        todayDate.setText("Today: " + getToday());


        entryForm = findViewById(R.id.entryForm);
        entriesContainer = findViewById(R.id.entriesContainer);

        entryTitle = findViewById(R.id.entryTitle);
        entryBody = findViewById(R.id.entryBody);

        todayButton = findViewById(R.id.todayButton);
        saveButton = findViewById(R.id.saveButton);
        cancelButton = findViewById(R.id.cancelButton);

        preferences = getSharedPreferences(
                PREFS, Context.MODE_PRIVATE);

        todayDate.setText("Today: " + getToday());
        findViewById(R.id.formDate).setContentDescription(
                "Date: " + getToday());
        ((TextView) findViewById(R.id.formDate))
                .setText("Date: " + getToday());

        sensorManager = (SensorManager)
                getSystemService(Context.SENSOR_SERVICE);

        accelerometer = sensorManager.getDefaultSensor(
                Sensor.TYPE_ACCELEROMETER);

        if (accelerometer == null) {
            sensorValues.setText(
                    "Accelerometer is not available on this device.");
        }

        displayEntries();

        addBounce(todayButton);
        addBounce(saveButton);
        addBounce(cancelButton);

        todayButton.setOnClickListener(v -> {
            ((TextView) findViewById(R.id.formDate))
                    .setText("Date: " + getToday());

            entryTitle.setText("");
            entryBody.setText("");
            entryForm.setVisibility(View.VISIBLE);
            entryTitle.requestFocus();
        });

        saveButton.setOnClickListener(v -> saveEntry());

        cancelButton.setOnClickListener(v -> {
            entryForm.setVisibility(View.GONE);
            entryTitle.setText("");
            entryBody.setText("");
        });

        createNotificationChannel();
        requestNotificationPermission();

        new AlertDialog.Builder(this)
                .setTitle("Welcome back Tanja!")
                .setMessage("Diary View.")
                .setPositiveButton("X", (dialog, which) ->
                        dialog.dismiss())
                .setCancelable(false)
                .show();
    }

    private String getToday() {
        return new SimpleDateFormat(
                "MMMM d, yyyy", Locale.getDefault())
                .format(new Date());
    }

    private String getTimestamp() {
        return new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss",
                Locale.getDefault()).format(new Date());
    }

    private void addBounce(Button button) {
        button.setOnTouchListener((view, event) -> {
            switch (event.getAction()) {
                case android.view.MotionEvent.ACTION_DOWN:
                    view.animate()
                            .scaleX(0.92f)
                            .scaleY(0.92f)
                            .setDuration(100)
                            .start();
                    break;

                case android.view.MotionEvent.ACTION_UP:
                case android.view.MotionEvent.ACTION_CANCEL:
                    view.animate()
                            .scaleX(1f)
                            .scaleY(1f)
                            .setDuration(350)
                            .setInterpolator(
                                    new OvershootInterpolator())
                            .start();
                    break;
            }
            return false;
        });
    }

    private void saveEntry() {
        String title = entryTitle.getText().toString().trim();
        String body = entryBody.getText().toString().trim();

        if (title.isEmpty()) {
            entryTitle.setError("Please enter a title");
            entryTitle.requestFocus();
            return;
        }

        if (body.isEmpty()) {
            entryBody.setError("Pour out your feelings!");
            entryBody.requestFocus();
            return;
        }

        try {
            JSONArray entries = new JSONArray(
                    preferences.getString(ENTRIES_KEY, "[]"));

            JSONObject entry = new JSONObject();

            entry.put("date", getToday());
            entry.put("timestamp", getTimestamp());
            entry.put("title", title);
            entry.put("body", body);

            entries.put(entry);

            preferences.edit()
                    .putString(ENTRIES_KEY, entries.toString())
                    .apply();

            entryForm.setVisibility(View.GONE);
            entryTitle.setText("");
            entryBody.setText("");

            displayEntries();

            Toast.makeText(this, "Diary entry saved!",
                    Toast.LENGTH_SHORT).show();

            showSavedNotification();

        } catch (Exception e) {
            Toast.makeText(this, "Could not save entry.",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void displayEntries() {
        entriesContainer.removeAllViews();

        try {
            JSONArray entries = new JSONArray(
                    preferences.getString(ENTRIES_KEY, "[]"));

            if (entries.length() == 0) {
                TextView empty = new TextView(this);
                empty.setText("No entries yet. Add your first thoughts!");
                empty.setTextColor(
                        android.graphics.Color.WHITE);
                empty.setPadding(4, 12, 4, 12);
                entriesContainer.addView(empty);
                return;
            }

            for (int i = entries.length() - 1; i >= 0; i--) {
                JSONObject entry = entries.getJSONObject(i);

                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(16, 14, 16, 14);
                card.setBackgroundResource(R.drawable.rounded_gray);

                LinearLayout.LayoutParams params =
                        new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.MATCH_PARENT,
                                LinearLayout.LayoutParams.WRAP_CONTENT);

                params.setMargins(0, 0, 0, 12);
                card.setLayoutParams(params);

                TextView date = new TextView(this);
                date.setText(entry.optString("date"));
                date.setTextColor(0xFF666666);
                date.setTextSize(13);

                TextView title = new TextView(this);
                title.setText(entry.optString("title"));
                title.setTextColor(0xFF444444);
                title.setTextSize(19);
                title.setTypeface(null,
                        android.graphics.Typeface.BOLD);

                TextView body = new TextView(this);
                body.setText(entry.optString("body"));
                body.setTextColor(0xFF555555);
                body.setTextSize(15);
                body.setPadding(0, 8, 0, 0);

                card.addView(date);
                card.addView(title);
                card.addView(body);

                card.setOnClickListener(v ->
                        new AlertDialog.Builder(MainActivity.this)
                                .setTitle(entry.optString("title"))
                                .setMessage(
                                        entry.optString("date")
                                                + "\n\n"
                                                + entry.optString("body"))
                                .setPositiveButton("Close",
                                        (dialog, which) ->
                                                dialog.dismiss())
                                .show());

                entriesContainer.addView(card);
            }

        } catch (Exception e) {
            Toast.makeText(this,
                    "Could not load diary entries.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel =
                    new NotificationChannel(
                            CHANNEL_ID,
                            "Diary notifications",
                            NotificationManager.IMPORTANCE_DEFAULT);

            channel.setDescription(
                    "Entry Notifications.");

            channel.enableVibration(true);
            channel.setVibrationPattern(
                    new long[]{0, 250, 150, 250});

            NotificationManager manager =
                    getSystemService(NotificationManager.class);

            manager.createNotificationChannel(channel);
        }
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(
                Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {

            requestPermissions(
                    new String[]{
                            Manifest.permission.POST_NOTIFICATIONS
                    }, 100);
        }
    }

    private void showSavedNotification() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(
                Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(this, CHANNEL_ID)
                        .setSmallIcon(
                                android.R.drawable.ic_menu_edit)
                        .setContentTitle("Memory saved")
                        .setContentText(
                                "Your memory has been saved, Tanja!")
                        .setPriority(
                                NotificationCompat.PRIORITY_DEFAULT)
                        .setAutoCancel(true);

        NotificationManagerCompat.from(this).notify(
                (int) System.currentTimeMillis(), builder.build());
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (sensorManager != null && accelerometer != null) {
            sensorManager.registerListener(
                    this, accelerometer,
                    SensorManager.SENSOR_DELAY_UI);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();

        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType()
                == Sensor.TYPE_ACCELEROMETER) {

            float x = event.values[0];
            float y = event.values[1];
            float z = event.values[2];

            sensorValues.setText(String.format(
                    Locale.US,
                    "PHONE MOVEMENT\nX: %.2f   Y: %.2f   Z: %.2f",
                    x, y, z));

            profileCircle.setRotation(-x * 3f);
        }
    }

    @Override
    public void onAccuracyChanged(
            Sensor sensor, int accuracy) {
    }
}